<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

{{-- google fonts link --}}
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">


  <link rel="stylesheet" href="{{url('css/main.css')}}"/>
  <link rel="stylesheet" href="{{url('css/registration.css')}}"/>

  <title>Flipkart</title>
</head>
<body>


  <div class="main-navbar">
    <div class="nav-link">
        <div class="logo"><a href="{{'index'}}">Shopholic</a></div>

        <div><input type="search" class="form-control" placeholder="Search products....">
        </div><input hidden type="submit"><i class="search_products fa fa-search text-primary"></i>

        <div><i class="user_icon fa fa-user-circle"></i></div>
        <div><button class="login_user"><a class="login_btn" href="{{url('/login')}}">Login</a></button></div>
        <div><a href="{{url('productcart')}}"><i class="cart fa fa-shopping-cart" aria-hidden="true">&nbsp; Cart</i></a></div>
    </div>
</div>
     <div class="container">
       <div class="register_account">
      <h1 style="font-weight: 600; text-align: center;">Create Account</h1>
      <h3 class="login-register"><a href="{{url('login')}}"> Existing User? Log in</a></h3> <br>
  <form action="{{url('store')}}" method="POST">

    @csrf
      <!-- <label>Name</label> -->
      <input type="text" class="form-control" name="name" value="" placeholder="Full Name">
      <!-- <label>Email</label> -->
      <input type="email" class="form-control" name="email" value="" placeholder="Email Address">
  
      <!-- <label>Mobile No.</label> -->
      <input type="number" class="form-control" name="mobile" value="" placeholder="Mobile No">
      <!-- <label>Gender</label>&nbsp;&nbsp;&nbsp; -->
      <input type="radio" class="form-control-check" name="gender" value="Male"><span class="allgender">Male</span> 
      <input type="radio" class="form-control-check" name="gender" value="Female"><span class="allgender">Female</span>
      <input type="radio" class="form-control-check" name="gender" value="Others"><span class="allgender">Others</span>
      <input type="date" class="form-control" name="dob" value="">  
      <!-- <label>City</label> -->
      <select id="" class="form-control" name="city">
        <option selected  value="">Select City</option>
        <option value="Ahmedabad">Ahmedabad</option>
        <option value="Vadodara">Vadodara</option>
        <option value="Surat">Surat</option>
        <option value="Bhavnagar">Bhavnagar</option>
        <option value="Botad">Botad</option>
        <option value="Rajkot">Rajkot</option>
      </select> 
      <!-- <label>Password</label> -->
      <input type="password" name="password" value="" class="form-control" placeholder="Enter Password">
     <br><br>
  
      <button type="submit" class="register_now" name="submit" value="">Register</button>
    </form>
    </div>
  </div>
    <br>
  
</body>

</html>