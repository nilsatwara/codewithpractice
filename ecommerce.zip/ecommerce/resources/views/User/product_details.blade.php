<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    {{-- <link rel="stylesheet" href="{{ url('css/main.css') }}" /> --}}
    <link rel="stylesheet" href="{{ url('css/products_home_display.css') }}" />
    <link rel="stylesheet" href="{{ url('css/product_details.css') }}" />
</head>

<body><br><br>
    <div class="container">

       
        @foreach ($product_list as $value)
      
        <div class="one_product">
            <div class="products_img" style="background-image:url('{{asset('/images/'.$value->photo_location.'/'.$value->product_photo)}}');"></div>
         
            <div class="product_title">
                <h4>{{$value->product_title}}</h4>


                {{-- <span>417 ratings & 64 reviews</span> &nbsp; &nbsp; &nbsp; --}}
                <span>ID:{{$value->product_id}}</span><br><br>
                <h3>{{ $value->product_new_price }}</h3>
                <h5 style="text-decoration:line-through; opacity:0.5">{{ $value->product_old_price }}</h5>
                <div class="product_list_highlight">
                    <span style="color: blue">{{ $value->key_features }}:</span>
                    <ul>
                        <li>{{ $value->feature1 }}</li>
                        <li>{{ $value->feature2 }}</li>
                        <li>{{ $value->feature3 }}</li>
                        <li>{{ $value->feature4 }}</li>
                        <li>{{ $value->feature5 }}</li>
                        <li>{{ $value->feature6 }}</li>

                    </ul>
                </div>
        
    </div>
    
    </div><hr>
    <div class="cart_buy_btn">
        <button class="add_to_cart_btn"><i class="fa fa-shopping-cart"></i>&nbsp; Add to Cart</button>
        <button class="buy_now_btn"><i class="fa fa-bolt"></i>&nbsp; Buy Now</button></div>
        @endforeach     
      
</div>
<hr>
<h2>Related Products</h2>
<hr>
{{-- <div class="container1"> --}}
   
<div class="ecom_category">

 
    @foreach ($product0 as $value)
    <div class="product_details">
      
        <a href="{{url('Product_Details/mobiles/'.$value->product_id)}}">
            <div class="products_img" style="background-image:url('{{asset('/images/'.$value->photo_location.'/' . $value->product_photo)}}');"></div>
            <div class="product_discription">{{$value->product_title}}</div></a></div> 
            {{-- <span>{{$value->product_new_price}} &nbsp;&nbsp;&nbsp;<span style="text-decoration: line-through;">{{$value->product_old_price}}</span></span> --}}
            @endforeach
        </div>
       
   
</div>

<br>
<br>
<br><hr>
<style>
    .container2 footer h4 a{
        text-decoration: none;
        color: black;
        font-size: 19px;
    }
    .container2 footer h4 a:hover{
        color: blue;
    }
    p{
     text-align: center;
     font-size: 17px;
    }
</style>
<div class="container2" style="background-color: rgb(255, 255, 255); height:20vh; box-shadow: 0 0 8px white;">
<footer style="box-shadow: 0 0 8px rgb(233, 228, 228);">
    <h2 class="text-center">Popular Searches</h2><br><br>
    <h4 class="text-center"><a href="{{url('product_list/mobiles')}}">Mobiles</a> | <a href="{{url('product_list/electronics')}}">Laptops</a> | <a href="{{url('product_list/mobiles')}}">Upcoming Mobiles</a> | <a href="{{url('product_list/appliances')}}">TV & Refrigerator</a> | <a href="{{url('product_list/furniture')}}">Furniture</a> | <a href="{{url('product_list/fashion')}}">Men's Clothes</a> | <a href="{{url('product_list/electronics')}}">Top Laptops Under 1,00,000</a> </h4>
<hr>
   <p>©2021 shopholic.com.All Rights Reserved</p>
</footer>
</div><br><br> 

</body>

</html>
