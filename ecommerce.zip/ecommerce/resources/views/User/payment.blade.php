<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


  <link rel="stylesheet" href="{{url('css/main.css')}}"/>
  <link rel="stylesheet" href="{{url('css/registration.css')}}"/>
  <link rel="stylesheet" href="{{url('css/dashboard.css')}}"/>
  <link rel="stylesheet" href="{{url('css/productcart.css')}}"/>


  <title>Flipkart</title>
</head>
<style>

</style>

<body>


  <div class="main-navbar">
    <div class="nav-link">
<div><img class="logo" src="{{('images/mainimages/logo.png')}}" alt=""></div>

<div><input type="search" class="form-control" placeholder="Search products....">
</div><input hidden type="submit"><i class="search_products fa fa-search text-primary"></i>
          
<h4 class="user_profile_name"><a href="{{url('update')}}">My Profile</a></h4>
<!-- <div></div> -->
       </div>
     </div>

    
    <h4 style="opacity: 0.7; margin-left: 50px;">payment</h4>
    
    <div class="container2">
        <div class="product_cart_box_list">
        

        


<div class="product_cart_box" style="background-image: url('{{url('images/laptops/laptop1.jpeg')}}');">
           
    <div class="product_cart_title"><h3><a href="#">HP 14s-dy2501TU (3T170PA#ACJ) Core i3 11td Gen Windows 10 Home Laptop (8GB RAM,
            256GB SSD, Intel UHD Graphics, MS Office, 35.56cm, Natural Silver)</a></h3>
    <h4 class="product_id">
            QTY : 1
        </h4>

   

</div>
</div>

</div>
        
        <div class="product_cart_pay">
            <h2>Payment Details</h2><hr>
            <table border="2">
                <tr>
                    <td>
                        Item total
                    </td>
                    <td>
                        ₹39990
                    </td>
                </tr>
                <tr>
                    <td>Delivery Charges</td>
                    <td>Free</td>
                </tr>
                <tr>
                    <td>Total Price</td>
                    <td>₹39990</td>
                </tr>
            </table><br><br><br>
            <button type="submit" class="payment_btn">Order Now</button>
        </div>

    </div>
</body>

</html>