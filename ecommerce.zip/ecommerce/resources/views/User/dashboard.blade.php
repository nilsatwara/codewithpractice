<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

{{-- google fonts link --}}
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">



</head>
<style>
    table tr th{
        text-align: center;
        font-size: 20px;
    }
    table tr td{
        text-align: center;
    }

    a{
        text-decoration: none;

    }
    .btn{

        border: none;

    }
    
</style>
<body><br>
    <button type="submit" name="submit" class="btn btn-primary">{!!'Add Customer'!!}</button>{!!'<h3 class="text-center">Register</h3>'!!}
    <br>
    <div>
        <table class="table table-bordered table-responsive table-hover">
            <thead>
                <tr>
                <th>User Id</th>
                <th>Name Of User</th>
                <th>Email</th>
                <th>Photo</th>
                <th>City</th>
                <th>Gender</th>
                <th>DOB</th>
                <th>Mobile No</th>
                <th>Status</th>
                <th colspan="4" class="text-center">Action</th>
            </tr>
            </thead>
            
           
                <tbody> 
                    @foreach ($customers as $value)
                    <tr>
                      
                    <td>{{$value->customer_id}}</td>
                    <td>{{$value->full_name}}</td>
                    <td>{{$value->email}}</td>
                    <td>{{$value->photo}}</td>
                    <td>{{$value->city}}</td>
                    <td>{{$value->gender}}</td>
                    <td>{{$value->dob}}</td>
                    <td>{{$value->mobile}}</td>
                    <td>{{$value->status}}</td>
                   
                    {{-- <td>{{$value->customer_id}}</td>
                    <td>{{$value->customer_id}}</td>
                    <td>{{$value->customer_id}}</td> --}}
                    <td><a href="" class="btn btn-success btn_create">Create</a></td>
                    <td><a href="" class="btn btn-info btn_show">Show</a></td>
                    <td><a href="" class="btn btn-warning btn_up">Update</a></td>
                    <td><a href = 'delete/{{ $value->customer_id}}' class="btn btn-danger btn_del">Delete</a>
                    {{-- @if ($value=='delete')
                        <span class="alert-success">Deleted</span>
                        @else
                        <span class="alert-danger">Failed</span>
                    @endif --}}
                    </td>
                    {{-- <td><a href="{{url('destroy/'($value->customer_id))}}" class="btn btn-danger btn_del">Delete</a></td> --}}
                   
                   
                </tr>
                @endforeach
                </tbody>
                
        </table>
    </div>
</body>
</html>