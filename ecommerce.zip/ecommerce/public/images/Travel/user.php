<?php
/**
 * Export to PHP Array plugin for PHPMyAdmin
 * @version 5.1.1
 */

/**
 * Database `ecom_project`
 */

/* `ecom_project`.`user` */
$user = array(
);
