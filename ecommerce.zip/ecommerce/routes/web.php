<?php

use App\Http\Controllers\Main_controller;
use App\Http\Controllers\Admin_controller;
use App\Http\Controllers\Crud_Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });


//     Route::get('stripe', [Main_controller::class,'stripe_payment']);

// Products Routes>>>>>>>>>>>>>>>>>>>>

Route::get('/', [Main_controller::class, 'Index']);
Route::get('productcart/{category?}/{id?}', [Main_controller::class, 'Product_cart']);
Route::get('wishlist', [Main_controller::class, 'Wish_list']);
// Route::get('add-to-cart/{id}', [Main_controller::class, 'Add_To_Cart'])->name('add.to.cart');
// Route::patch('update-cart', [ProductController::class, 'Update'])->name('update.cart');
// Route::delete('remove-from-cart', [ProductController::class, 'Remove'])->name('remove.from.cart');
Route::get('payment', [Main_controller::class, 'Payment']);


Route::get('Product_Details/{category?}/{id?}', [Main_controller::class, 'Product_Details']);
Route::get('product_list/{category?}', [Main_controller::class, 'Displaydata']);

//Crud Operations

Route::get('registration', [Crud_Controller::class, 'create']);
Route::get('update', [Crud_Controller::class, 'update']);
Route::post('store', [Crud_Controller::class, 'store']);
Route::get('dashboard', [Crud_Controller::class, 'show']);
Route::get('delete/{id?}', [Crud_Controller::class, 'destroy']);



Route::get('/login', [Crud_Controller::class, 'Login']);
Route::post('/process-login', [Crud_Controller::class, 'Process_Login']);
Route::get('/process-login', [Crud_Controller::class, 'Login']);
    // Route::get('dashboard',[Crud_Controller::class,'Dashboard']);
    // Route::post('registration',[Crud_Controller::class,'Register']);
    // Route::get('registration',[Crud_Controller::class,'index']);
    // Route::get('registration',[Crud_Controller::class,'index']);
