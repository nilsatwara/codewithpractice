<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <link rel="stylesheet" href="<?php echo e(url('css/main.css')); ?>"/>
 <link rel="stylesheet" href="<?php echo e(url('css/loginuser.css')); ?>"/>

  <title>Flipkart</title>
</head>
<style>
.wrapper{
  width: 400px;
  margin: 0 auto;
  text-align: center; 
  border: 1px solid #000;
}
.error{
  font-size: 18px;
  background-color: rgb(255, 255, 255);
  text-align: center;
}
</style>

<body>


  <div class="main-navbar">
    <div class="nav-link">
        <div class="logo"><a href="<?php echo e('index'); ?>">Shopholic</a></div>

        <div><input type="search" class="form-control" placeholder="Search products....">
        </div><input hidden type="submit"><i class="search_products fa fa-search text-primary"></i>

        <div><i class="user_icon fa fa-user-circle"></i></div>
        <div><button class="login_user"><a class="login_btn" href="<?php echo e(url('registration')); ?>">Register</a></button></div>
        <div><a href="<?php echo e(url('productcart')); ?>"><i class="cart fa fa-shopping-cart" aria-hidden="true">&nbsp; Cart</i></a></div>
    </div>
</div>
  <?php if(Session::get('message')): ?>
  <?php echo e(Session::get('message')); ?>

  <?php endif; ?>

     <div class="container">       
       
       <div class="login_account">
      
      <h1 style="font-weight: 600; text-align: center;">Login</h1>

      <h3 class="login-register"><a href="<?php echo e(url('registration')); ?>">New to Shopholic? Create an account</a></h3> <br>
      
      <form action="<?php echo e(url('index')); ?>" method="post">

        <?php echo csrf_field(); ?>

      <input type="email" class="form-control" name="email" value="" placeholder="Enter Email" required>
  
    
      <input type="password" name="password" value="" class="form-control" placeholder="Enter Password" required>
     <br><br>
  
      <button type="submit" class="login_now_btn" name="submit" value="">Login</button>
    </form>
    </div>
  </div>
    <br>
  
</body>

</html><?php /**PATH C:\xampp\htdocs\php_project\flipkart\ecommerce\resources\views/User/login.blade.php ENDPATH**/ ?>