<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">



</head>
<style>
    table tr th{
        text-align: center;
        font-size: 20px;
    }
    table tr td{
        text-align: center;
    }

    a{
        text-decoration: none;

    }
    .btn{

        border: none;

    }
    
</style>
<body><br>
    <button type="submit" name="submit" class="btn btn-primary"><?php echo 'Add Customer'; ?></button><?php echo '<h3 class="text-center">Register</h3>'; ?>

    <br>
    <div>
        <table class="table table-bordered table-responsive table-hover">
            <thead>
                <tr>
                <th>User Id</th>
                <th>Name Of User</th>
                <th>Email</th>
                <th>Photo</th>
                <th>City</th>
                <th>Gender</th>
                <th>DOB</th>
                <th>Mobile No</th>
                <th>Status</th>
                <th colspan="4" class="text-center">Action</th>
            </tr>
            </thead>
            
           
                <tbody> 
                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      
                    <td><?php echo e($value->customer_id); ?></td>
                    <td><?php echo e($value->full_name); ?></td>
                    <td><?php echo e($value->email); ?></td>
                    <td><?php echo e($value->photo); ?></td>
                    <td><?php echo e($value->city); ?></td>
                    <td><?php echo e($value->gender); ?></td>
                    <td><?php echo e($value->dob); ?></td>
                    <td><?php echo e($value->mobile); ?></td>
                    <td><?php echo e($value->status); ?></td>
                   
                    
                    <td><a href="" class="btn btn-success btn_create">Create</a></td>
                    <td><a href="" class="btn btn-info btn_show">Show</a></td>
                    <td><a href="" class="btn btn-warning btn_up">Update</a></td>
                    <td><a href = 'delete/<?php echo e($value->customer_id); ?>' class="btn btn-danger btn_del">Delete</a>
                    
                    </td>
                    
                   
                   
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                
        </table>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\php_project\flipkart\ecommerce\resources\views/User/dashboard.blade.php ENDPATH**/ ?>