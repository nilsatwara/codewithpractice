<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
     <!-- Bootstrap JS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
 <!-- Font-Awasome Icon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <!-- Google fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600&display=swap" rel="stylesheet">

    
    <link rel="stylesheet" href="<?php echo e(url('css/main.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(url('css/products_home_display.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(url('css/loginuser.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(url('css/registration.css')); ?>"/>

    <title>Flipkart</title>
</head>
<style>
   
</style>

<body>


    <div class="main-navbar">
        <div class="nav-link">
            <div class="logo"><a href="<?php echo e('/'); ?>">Shopholic</a></div>

            <div><input type="search" class="form-control" placeholder="Search products....">
            </div><input hidden type="submit"><i class="search_products fa fa-search text-primary"></i>

            <div><i class="user_icon fa fa-user-circle"></i></div>
            <div><button class="login_user"><a class="login_btn" href="<?php echo e(url('/login')); ?>">Login</a></button></div>
            <div><a href="<?php echo e(url('productcart')); ?>"><i class="cart fa fa-shopping-cart" aria-hidden="true">&nbsp; Cart</i></a></div>
        </div>
    </div>

    <div class="product">
        <div class="sub_category"><a href="<?php echo e(url('product_list/mobiles')); ?>"><img src="<?php echo e(url('images/mainimages/i1.png')); ?>" alt=""></a>
            <p class="cat1">Mobiles</p>
        </div>
        <div class="sub_category "><a href="<?php echo e(url('product_list/fashion')); ?>"><img src="<?php echo e(url('images/mainimages/i2.png')); ?>" alt=""></a>
            <p class="cat1">Fashion</p>
        </div>
        <div class="sub_category"><a href="<?php echo e(url('product_list/electronics')); ?>"><img src="<?php echo e(url('images/mainimages/i3.png')); ?>" alt=""></a>
            <p class="cat1">Electronics</p>
        </div>
        <div class="sub_category"><a href="<?php echo e(url('product_list/travelbags')); ?>"><img src="<?php echo e(url('images/mainimages/i5.png')); ?>" alt=""></a>
            <p class="cat1">Travel</p>
        </div>
        <div class="sub_category"><a href="<?php echo e(url('product_list/appliances')); ?>"><img src="<?php echo e(url('images/mainimages/i6.jpg')); ?>" alt=""></a>
            <p class="cat1">Appliances</p>
        </div>
        <div class="sub_category"><a href="<?php echo e(url('product_list/furniture')); ?>"><img src="<?php echo e(url('images/mainimages/i7.png')); ?>" alt=""></a>
            <p class="cat1">Furniture</p>
        </div>
        <div class="sub_category"><a href="<?php echo e(url('product_list/footwear')); ?>"><img style="border-radius: 100%; border:3px solid orange; width:45%" src="<?php echo e(url('images/mainimages/i9.jpeg')); ?>" alt=""></a>
            <p class="cat1">Footwear</p>
        </div>
    </div>

    <hr>

    <div>

        <div id="myCarousel" class="carousel slide" data-ride="carousel">

            <!-- Wrapper for slides -->
             <div class="carousel-inner">
                <div class="item active">
                    <img src="<?php echo e(url('images/mainimages/banner1.jpg')); ?>" class="banner">
                </div>

                <div class="item">
                    <img class="banner" src="<?php echo e(url('images/mainimages/banner2.jpg')); ?>" alt="">
                </div>

                <div class="item">
                    <img class="banner" src="<?php echo e(url('images/mainimages/banner3.jpg')); ?>" alt="">
                </div>
            </div> 
            <!-- Left and right controls -->
            <a class="left carousel-control" href="#myCarousel" data-slide="prev">
                <span class="glyphicon glyphicon-chevron-left"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="right carousel-control" href="#myCarousel" data-slide="next">
                <span class="glyphicon glyphicon-chevron-right"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>
    <br>
    <hr>


    <div class="col">
        <div class="card col-lg-4">
            <img src="<?php echo e(url('images/mainimages/ad1.jpg')); ?>" class="card-img-top" alt="...">
        </div>
    </div>
    <div class="col">
        <div class="card col-lg-4">
            <img src="<?php echo e(url('images/mainimages/ad2.jpg')); ?>" class="card-img-top" alt="...">
        </div>
    </div>
    <div class="col">
        <div class="card col-lg-4">
            <img src="<?php echo e(url('images/mainimages/ad3.jpg')); ?>" class="card-img-top">
            <hr>
        </div>
    </div>
 
    <div class="offers">Biggest Deals on Mobiles</div>
    <hr>
   
   
    <div class="ecom_category">
        <?php $__currentLoopData = $product1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       
        <div class="product_details">
            <a href="<?php echo e(url('Product_Details/mobiles/'.$value->product_id)); ?>">
            <div class="products_img" style="background-image:url('<?php echo e(asset('/images/'.$value->photo_location.'/' . $value->product_photo)); ?>');width:250px; height:200px;margin:auto; margin-top:20px;"></div><br>
            <p class="product_discription"><?php echo e($value->product_title); ?></p></a>
                <span><?php echo e($value->product_new_price); ?> &nbsp;&nbsp;&nbsp;</span>
                <span style="text-decoration: line-through;opacity:0.7;"><?php echo e($value->product_old_price); ?></span>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
       
        <br><br><br>
        <div class="offers">25% Off On Laptops</div>
      <hr>
      <div class="ecom_category">
        <?php $__currentLoopData = $product6; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       
        <div class="product_details">
            <a href="<?php echo e(url('Product_Details/electronics/'.$value->product_id)); ?>">
            <div class="products_img" style="background-image:url('<?php echo e(asset('/images/'.$value->photo_location.'/' . $value->product_photo)); ?>'); width:250px;margin:auto; margin-top:20px;"></div>
            <p class="product_discription"><?php echo e($value->product_title); ?></p></a>
                <span><?php echo e($value->product_new_price); ?> &nbsp;&nbsp;&nbsp;</span>
                <span style="text-decoration: line-through;opacity:0.7;"><?php echo e($value->product_old_price); ?></span>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

    <br><br><br>
        <div class="offers">Best Deals on Men Clothes</div>
      <hr>
      <div class="ecom_category">
        <?php $__currentLoopData = $product3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       
        <div class="product_details">
            <a href="<?php echo e(url('Product_Details/fashion/'.$value->product_id)); ?>">
            <div class="products_img" style="background-image:url('<?php echo e(asset('/images/'.$value->photo_location.'/' . $value->product_photo)); ?>');"></div>
            <p class="product_discription"><?php echo e($value->product_title); ?></p></a>
                <span><?php echo e($value->product_new_price); ?> &nbsp;&nbsp;&nbsp;</span>
                <span style="text-decoration: line-through;opacity:0.7;"><?php echo e($value->product_old_price); ?></span>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
    <br><br><br>
    <div class="offers">50% OFF on Top brands footwear</div>
  <hr>
  <div class="ecom_category">
    <?php $__currentLoopData = $product4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   
    <div class="product_details">
        <a href="<?php echo e(url('Product_Details/footwear/'.$value->product_id)); ?>">
        <div class="products_img" style="background-image:url('<?php echo e(asset('/images/'.$value->photo_location.'/' . $value->product_photo)); ?>');width:240px; height:200px;margin:auto; margin-top:20px;"></div>
        <p class="product_discription"><?php echo e($value->product_title); ?></p></a>
            <span><?php echo e($value->product_new_price); ?> &nbsp;&nbsp;&nbsp;</span>
            <span style="text-decoration: line-through;opacity:0.7;"><?php echo e($value->product_old_price); ?></span>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

<br><br><br>
<div class="offers">80% off on Travel bags</div>
<hr>
<div class="ecom_category">
    <?php $__currentLoopData = $product7; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   
    <div class="product_details">
        <a href="<?php echo e(url('Product_Details/travelbags/'.$value->product_id)); ?>">
        <div class="products_img" style="background-image:url('<?php echo e(asset('/images/'.$value->photo_location.'/' . $value->product_photo)); ?>');width:240px; height:200px;margin:auto; margin-top:20px;"></div><br>
        <p class="product_discription"><?php echo e($value->product_title); ?></p></a>
            <span><?php echo e($value->product_new_price); ?> &nbsp;&nbsp;&nbsp;</span>
            <span style="text-decoration: line-through;opacity:0.7;"><?php echo e($value->product_old_price); ?></span>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>



    <br><br><br>
    <div class="offers">Tv & Appliances Up to 80% off</div>
  <hr>
  <div class="ecom_category">
    <?php $__currentLoopData = $product5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   
    <div class="product_details">
        <a href="<?php echo e(url('Product_Details/appliances/'.$value->product_id)); ?>">
        <div class="products_img" style="background-image:url('<?php echo e(asset('/images/'.$value->photo_location.'/' . $value->product_photo)); ?>');width:240px;margin:auto; margin-top:20px;"></div><br>
        <p class="product_discription"><?php echo e($value->product_title); ?></p></a>
            <span><?php echo e($value->product_new_price); ?> &nbsp;&nbsp;&nbsp;</span>
            <span style="text-decoration: line-through;opacity:0.7;"><?php echo e($value->product_old_price); ?></span>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

<br><br><br>
    <div class="offers">Furniture Up to 60% off</div>
  <hr>
  <div class="ecom_category">
    <?php $__currentLoopData = $product2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   
    <div class="product_details">
        <a href="<?php echo e(url('Product_Details/furniture/'.$value->product_id)); ?>">
        <div class="products_img" style="background-image:url('<?php echo e(asset('/images/'.$value->photo_location.'/' . $value->product_photo)); ?>');width:250px;margin:auto; margin-top:20px;"></div><br>
        <p class="product_discription"><?php echo e($value->product_title); ?></p></a>
            <span><?php echo e($value->product_new_price); ?> &nbsp;&nbsp;&nbsp;</span>
            <span style="text-decoration: line-through;opacity:0.7;"><?php echo e($value->product_old_price); ?></span>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
<br>
<br>
<br><hr>
<style>
    .container footer h4 a{
        text-decoration: none;
    }
    p{
     text-align: center;
     font-size: 17px;
    }
</style>
<div class="container" style="background-color: rgb(255, 255, 255); height:20vh; box-shadow: 0 0 8px white;">
<footer style="box-shadow: 0 0 8px rgb(233, 228, 228);">
    <h2 class="text-center">Popular Searches</h2><br><br>
    <h4 class="text-center"><a href="<?php echo e(url('product_list/mobiles')); ?>">Mobiles</a> | <a href="<?php echo e(url('product_list/electronics')); ?>">Laptops</a> | <a href="<?php echo e(url('product_list/mobiles')); ?>">Upcoming Mobiles</a> | <a href="<?php echo e(url('product_list/appliances')); ?>">TV & Refrigerator</a> | <a href="<?php echo e(url('product_list/furniture')); ?>">Furniture</a> | <a href="<?php echo e(url('product_list/fashion')); ?>">Men's Clothes</a> | <a href="<?php echo e(url('product_list/electronics')); ?>">Top Laptops Under 1,00,000</a> </h4>
<hr>
   <p>©2021 shopholic.com.All Rights Reserved</p>
</footer>
</div><br><br> 
</body>

</html><?php /**PATH C:\xampp\htdocs\php_project\flipkart\ecommerce\resources\views/index.blade.php ENDPATH**/ ?>