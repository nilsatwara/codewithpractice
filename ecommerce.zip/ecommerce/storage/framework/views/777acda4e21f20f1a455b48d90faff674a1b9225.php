<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@700&display=swap" rel="stylesheet">


    
    <link rel="stylesheet" href="<?php echo e(url('css/products_home_display.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(url('css/product_details.css')); ?>" />
</head>

<body>
    <div class="container">

       
        <?php $__currentLoopData = $product1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
        <div class="one_product">
            <div class="products_img" style="background-image:url('<?php echo e(asset('/images/'.$value->photo_location.'/'.$value->product_photo)); ?>');"></div>
         
            <div class="product_title">
                <h4><?php echo e($value->product_title); ?></h4>


                
                <span>ID:<?php echo e($value->product_id); ?></span><br><br>
                <h3><?php echo e($value->product_new_price); ?></h3>
                <h5 style="text-decoration:line-through; opacity:0.5"><?php echo e($value->product_old_price); ?></h5>
                <div class="product_list_highlight">
                    <span style="color: blue"><?php echo e($value->key_features); ?>:</span>
                    <ul>
                        <li><?php echo e($value->feature1); ?></li>
                        <li><?php echo e($value->feature2); ?></li>
                        <li><?php echo e($value->feature3); ?></li>
                        <li><?php echo e($value->feature4); ?></li>
                        <li><?php echo e($value->feature5); ?></li>
                        <li><?php echo e($value->feature6); ?></li>

                    </ul>
                </div>
        
    </div>
    
    </div><hr>
    <div class="cart_buy_btn">
        <button class="add_to_cart_btn"><i class="fa fa-shopping-cart"></i>&nbsp; Add to Cart</button>
        <button class="buy_now_btn"><i class="fa fa-bolt"></i>&nbsp; Buy Now</button></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
      
</div>
<hr>
<h2>Related Products</h2>
<hr>
<div class="container1">
   
<div class="ecom_category">

    <?php $__currentLoopData = $product2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="product_details">
        <a href="<?php echo e(url('product_list/mobiles', [$value->product_id])); ?>"> 
            <div class="products_img" style="background-image:url('<?php echo e(asset('/images/'.$value->photo_location.'/' . $value->product_photo)); ?>');"></div>
            <div class="product_discription"><?php echo e($value->product_title); ?></div></a></div> 
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
  
   
</div>

<br>
<br>
<br><hr>
<style>
    .container2 footer h4 a{
        text-decoration: none;
        color: black;
        font-size: 19px;
    }
    .container2 footer h4 a:hover{
        color: blue;
    }
    p{
     text-align: center;
     font-size: 17px;
    }
</style>
<div class="container2" style="background-color: rgb(255, 255, 255); height:20vh; box-shadow: 0 0 8px white;">
<footer style="box-shadow: 0 0 8px rgb(233, 228, 228);">
    <h2 class="text-center">Popular Searches</h2><br><br>
    <h4 class="text-center"><a href="<?php echo e(url('product_list/mobiles')); ?>">Mobiles</a> | <a href="<?php echo e(url('product_list/electronics')); ?>">Laptops</a> | <a href="<?php echo e(url('product_list/mobiles')); ?>">Upcoming Mobiles</a> | <a href="<?php echo e(url('product_list/appliances')); ?>">TV & Refrigerator</a> | <a href="<?php echo e(url('product_list/furniture')); ?>">Furniture</a> | <a href="<?php echo e(url('product_list/fashion')); ?>">Men's Clothes</a> | <a href="<?php echo e(url('product_list/electronics')); ?>">Top Laptops Under 1,00,000</a> </h4>
<hr>
   <p>©2021 shopholic.com.All Rights Reserved</p>
</footer>
</div><br><br> 

</body>

</html>
<?php /**PATH C:\xampp\htdocs\php_project\flipkart\ecommerce\resources\views/User/one_product.blade.php ENDPATH**/ ?>