<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

 <link rel="stylesheet" href="<?php echo e(url('css/main.css')); ?>"/>
 <link rel="stylesheet" href="<?php echo e(url('css/product_list.css')); ?>"/>


  <title>Flipkart</title>
</head>

<body>


    <div class="main-navbar">
        <div class="nav-link">
            <div class="logo"><a href="<?php echo e('/'); ?>">Shopholic</a></div>

            <div><input type="search" class="form-control" placeholder="Search products....">
            </div><input hidden type="submit"><i class="search_products fa fa-search text-primary"></i>

            <div><i class="user_icon fa fa-user-circle"></i></div>
            <div><button class="login_user"><a class="login_btn" href="<?php echo e(url('/login')); ?>">Login</a></button></div>
            <div><a href="<?php echo e(url('productcart')); ?>"><i class="cart fa fa-shopping-cart" aria-hidden="true">&nbsp; Cart</i></a></div>
        </div>
    </div>
    <?php $__currentLoopData = $product_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php if($key % 2 == 0 && $key > 1): ?>
        <div class="container">
        <div  class="product_list">
            <div class="products_img" style="background-image:url('<?php echo e(asset('/images/'.$product_item->photo_location.'/'.$product_item->product_photo)); ?>'); background-size:contain;background-repeat:no-repeat;width:300px;height:260px ">

             
            
            </div>
            <div class="product_title">
                <div class="title"><?php echo e($product_item->product_title); ?></div>

                
                <span>Product Id: <?php echo e($product_item->product_id); ?></span>
                <h3><?php echo e($product_item->product_new_price); ?></h3>
                <h5 style="text-decoration:line-through; opacity:0.5"><?php echo e($product_item->product_old_price); ?></h5><br><br>
                <button class="buy" type="submit" name="submit" value=""><a href="<?php echo e(url('productcart/'.$category.'/'.$product_item->product_id)); ?>">
                    
                    Buy Now</a>
                    
                
                
                
                </button>&nbsp;&nbsp; &nbsp;
                <button class="add_cart" type="submit" name="cart" value="">Add To Cart</button>
                <div class="product_list_highlight">
                    
                    
                </div>

            </div>
        
    </div>


            <?php elseif($key %2 !=0 && $key > 1): ?>
            
            <div  class="product_list">
                <div class="products_img" style="background-image:url('<?php echo e(asset('/images/'.$product_item->photo_location.'/'.$product_item->product_photo)); ?>'); background-size:contain;background-repeat:no-repeat;width:300px;height:260px ">

    
                  
                
                </div>
                <div class="product_title">
                    <div class="title"><?php echo e($product_item->product_title); ?></div>
    
                    
                    <span>Product Id: <?php echo e($product_item->product_id); ?></span>
                    <h3><?php echo e($product_item->product_new_price); ?></h3>
                    <h5 style="text-decoration:line-through; opacity:0.5"><?php echo e($product_item->product_old_price); ?></h5><br><br>
                    <button class="buy" type="submit" name="submit" value=""><a href="<?php echo e(url('productcart/'.$category.'/'.$product_item->product_id)); ?>">
                    
                        Buy Now</a>
                        
                    
                    
                    
                    </button>&nbsp;&nbsp; &nbsp;
                    <button class="add_cart" type="submit" name="cart" value="">Add To Cart</button>
                    <div class="product_list_highlight">
                        
                    </div>
    
                </div>
            
        </div>
        </div>
    
        <?php endif; ?>
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
    
    <br>
    <br>
    <br><hr>
    <style>
       
        .container1 footer h4 a{
            text-decoration: none;
        }
        p{
         text-align: center;
         font-size: 17px;
        }
    </style>
    <div class="container1" style="background-color: rgb(255, 255, 255); height:20vh; box-shadow: 0 0 8px white;">
    <footer style="box-shadow: 0 0 8px rgb(233, 228, 228);">
        <h2 class="text-center">Popular Searches</h2><br><br>
        <h4 class="text-center"><a href="<?php echo e(url('product_list/mobiles')); ?>">Mobiles</a> | <a href="<?php echo e(url('product_list/electronics')); ?>">Laptops</a> | <a href="<?php echo e(url('product_list/mobiles')); ?>">Upcoming Mobiles</a> | <a href="<?php echo e(url('product_list/appliances')); ?>">TV & Refrigerator</a> | <a href="<?php echo e(url('product_list/furniture')); ?>">Furniture</a> | <a href="<?php echo e(url('product_list/fashion')); ?>">Men's Clothes</a> | <a href="<?php echo e(url('product_list/electronics')); ?>">Top Laptops Under 1,00,000</a> </h4>
    <hr>
       <p>©2021 flipkart.com.All Rights Reserved</p>
    </footer>
    </div><br><br>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\php_project\flipkart\ecommerce\resources\views/User/product_list.blade.php ENDPATH**/ ?>