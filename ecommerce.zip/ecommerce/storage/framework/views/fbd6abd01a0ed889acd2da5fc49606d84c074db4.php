<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600&display=swap" rel="stylesheet">



    <link rel="stylesheet" href="<?php echo e(url('css/main.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(url('css/productcart.css')); ?>" />


    <title>Shopholic</title>
</head>
<body>


    <div class="main-navbar">
        <div class="nav-link">
            <div class="logo"><a href="<?php echo e('/'); ?>">Shopholic</a></div>

            <div><input type="search" class="form-control" placeholder="Search products....">
            </div><input hidden type="submit"><i class="search_products fa fa-search text-primary"></i>

            <h4 class="user_profile_name"><a href="<?php echo e(url('updateuser')); ?>">My Profile</a></h4>

        </div>
    </div>
<div class="container-fluid">
    <div class="container">
        <div class="product_cart">
    <?php $__currentLoopData = $product6; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h3>My Cart</h3>
    <div class="product_details">
    
       <a href="<?php echo e(url('product_list/mobiles', [$value->product_id])); ?>"> 
       <div class="products_img" style="background-image:url('<?php echo e(asset('/images/'.$value->photo_location.'/'.$value->product_photo)); ?>');"></div></a>
       <div class="product_discription"> <br>
       <a style="text-decoration: none;" href="<?php echo e(url('product_list/mobiles', [$value->product_id])); ?>"><p style="font-size: 20px; color:black"><?php echo $value->product_title; ?></p></a>
        <span><?php echo e($value->product_new_price); ?> &nbsp;&nbsp;&nbsp;</span>
            <span style="text-decoration: line-through;opacity:0.7;"><?php echo e($value->product_old_price); ?></span>
    </div>
           
       </div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

       </div>
    
       <div class="product_cart">
        <?php $__currentLoopData = $product6; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="product_details">
        
           <a href="<?php echo e(url('product_list/mobiles', [$value->product_id])); ?>"> 
           <div class="products_img" style="background-image:url('<?php echo e(asset('/images/'.$value->photo_location.'/'.$value->product_photo)); ?>');"></div></a>
           <div class="product_discription"> <br>
           <a style="text-decoration: none;" href="<?php echo e(url('product_list/mobiles', [$value->product_id])); ?>"><p style="font-size: 20px; color:black"><?php echo $value->product_title; ?></p></a>
            <span><?php echo e($value->product_new_price); ?> &nbsp;&nbsp;&nbsp;</span>
                <span style="text-decoration: line-through;opacity:0.7;"><?php echo e($value->product_old_price); ?></span>
        </div>
               
           </div>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
           </div>
               </div>
        
        
    
               <div class="container">
    <div class="product_cart_pay"><br>
    <h2>Payment Details</h2>
    <hr>
    <table border="2">
       <tr>
           <td>
               Item total
           </td>
           <td>
               ₹39990
           </td>
       </tr>
       <tr>
           <td>Delivery Charges</td>
           <td>Free</td>
       </tr>
       <tr>
           <td>Total Price</td>
           <td>₹39990</td>
       </tr>
    </table><br><br><br>
    <button type="submit" name="" class="payment_btn">Checkout</button>
    </div>
    
    </div>  
</div>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\php_project\flipkart\ecommerce\resources\views/User/wishlist.blade.php ENDPATH**/ ?>