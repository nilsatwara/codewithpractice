<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class model_fashion extends Model
{
    use HasFactory;

    protected $table = 'fashion';
    protected $primaryKey = 'product_id';
}
