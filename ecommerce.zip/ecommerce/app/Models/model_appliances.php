<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class model_appliances extends Model
{
    use HasFactory;

    protected $table = 'appliances';
    protected $primaryKey = 'product_id';

}
