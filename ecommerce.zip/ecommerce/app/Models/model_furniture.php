<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class model_furniture extends Model
{
    use HasFactory;

    protected $table = 'furniture';
    protected $primaryKey = 'product_id';
}
