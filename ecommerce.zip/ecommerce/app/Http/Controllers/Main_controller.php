<?php

namespace App\Http\Controllers;

use App\Models\model_mobile;
use App\Models\model_appliances;
use App\Models\model_furniture;
use App\Models\model_electronics;
use App\Models\model_fashion;
use App\Models\model_travelbag;
use App\Models\model_footwear;
use App\Models\cart_model;
use Illuminate\Http\Request;


class Main_controller extends Controller
{
    public function Index()
    {

        $product1 = model_mobile::all();
        $product1 = $product1->only([145265, 145266, 145267, 145268, 145269]);

        $product2 = model_furniture::all();
        $product2 = $product2->only([205012, 205013, 205014, 205015, 205016]);

        $product3 = model_fashion::all();
        $product3 = $product3->only([305025, 305026, 305027, 305028, 305029]);

        $product4 = model_footwear::all();
        $product4 = $product4->only([412354, 412355, 412356, 412357, 412358]);

        $product5 = model_appliances::all();
        $product5 = $product5->only([501214, 501215, 501216, 501222, 501218]);

        $product6 = model_electronics::all();
        $product6 = $product6->only([601214, 601215, 601216, 601217, 601218]);

        $product7 = model_travelbag::all();
        $product7 = $product7->only([712313, 712314, 712315, 712316, 712317]);


        $product = compact('product1', 'product2', 'product3', 'product4', 'product5', 'product6', 'product7');
        return view('index')->with($product);
    }


    public function Product_cart(Request $request, $category, $id)
    {

        if ($category == 'mobiles') {
            $product_list = model_mobile::all();
            $product_list = $product_list->only($id);
        }

        if ($category == 'appliances') {
            $product_list =  model_appliances::all();
            $product_list = $product_list->only($id);
        }

        if ($category == 'fashion') {
            $product_list = model_fashion::all();
            $product_list = $product_list->only($id);
        }

        if ($category == 'electronics') {
            $product_list = model_electronics::all();
            $product_list = $product_list->only($id);
        }

        if ($category == 'furniture') {
            $product_list = model_furniture::all();
            $product_list = $product_list->only($id);
        }

        if ($category == 'footwear') {
            $product_list =  model_footwear::all();
            $product_list = $product_list->only($id);
        }

        if ($category == 'travelbags') {
            $product_list =  model_travelbag::all();
            $product_list = $product_list->only($id);
        }

        $product = compact('product_list', 'category');


        return view('User/productcart')->with($product);
    }

    public function Payment()
    {
        return view('User/payment');
    }

    public function Product_list()
    {
        return view('User/product_list');
    }

    public function Product_Details(Request $request,  $category, $id)
    {
        if ($category == 'mobiles') {
            $product_list = model_mobile::all();
            $product_list = $product_list->only($id);
            $product0 = model_mobile::all();
            $product0 = $product0->only([145265, 145266, 145267, 145268, 145269]);
        }



        if ($category == 'appliances') {
            $product_list =  model_appliances::all();
            $product_list = $product_list->only($id);
            $product0 = model_appliances::all();
            $product0 = $product0->only([501214, 501215, 501216, 501222, 501218]);
        }

        if ($category == 'fashion') {
            $product_list = model_fashion::all();
            $product_list = $product_list->only($id);
            $product0 = model_fashion::all();
            $product0 = $product0->only([305025, 305026, 305027, 305028, 305029]);
        }

        if ($category == 'electronics') {
            $product_list = model_electronics::all();
            $product_list = $product_list->only($id);
            $product0 = model_electronics::all();
            $product0 = $product0->only([601214, 601215, 601216, 601217, 601218]);
        }

        if ($category == 'furniture') {
            $product_list = model_furniture::all();
            $product_list = $product_list->only($id);
            $product0 = model_furniture::all();
            $product0 = $product0->only([205012, 205013, 205014, 205015, 205016]);
        }

        if ($category == 'footwear') {
            $product_list =  model_footwear::all();
            $product_list = $product_list->only($id);
            $product0 = model_footwear::all();
            $product0 = $product0->only([412354, 412355, 412356, 412357, 412358]);
        }

        if ($category == 'travelbags') {
            $product_list =  model_travelbag::all();
            $product_list = $product_list->only($id);
            $product0 = model_travelbag::all();
            $product0 = $product0->only([712313, 712314, 712315, 712316, 712317]);
        }
        $product = compact('product_list', 'category', 'product0');
        return view('User/product_details')->with($product);
    }

    public function Travel()
    {
        return view('User/travelbags');
    }

    public function Footwear()
    {
        return view('User/footwear');
    }


    public function Displaydata(Request $request, $category)
    {

        // $product_list = [];

        if ($category == 'mobiles') {

            $product_list = model_mobile::all();
        }

        if ($category == 'appliances') {
            $product_list =  model_appliances::all();
        }

        if ($category == 'fashion') {
            $product_list = model_fashion::all();
        }

        if ($category == 'electronics') {
            $product_list = model_electronics::all();
        }

        if ($category == 'furniture') {
            $product_list = model_furniture::all();
        }

        if ($category == 'footwear') {
            $product_list =  model_footwear::all();
        }

        if ($category == 'travelbags') {
            $product_list =  model_travelbag::all();
            $product7 = model_travelbag::all();
            $product7 = $product7->only([712313, 712314, 712315, 712316, 712317]);
        }



        $product = compact('category', 'product_list');

        return view('User/product_list')->with($product);

        // echo "<pre>";
        //         print_r($product_list);
        //         die;
    }
}
